package com.myapp.leavemanagementsystem;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText empid,username,empdept,email,phoneno,Reasonofleave,descriptionbox,sdate,edate;


    Calendar c;
    DatePickerDialog dpd;

    private Button startdate,enddate,save,btnview;
    private String sendUrl="https://androidappforbisleri.000webhostapp.com/test/getData.php";
    private RequestQueue requestQueue;
    private  static  final  String TAG=MainActivity.class.getSimpleName();
    int sucess;
    private String TAG_SUCESS="sucess";
    private String TAG_MESSAGE="message";
    private String tag_json_obj="json_obj_req";
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        empid=findViewById(R.id.empid);
        username=findViewById(R.id.txtUsername);
        empdept=findViewById(R.id.empdept);
        email=findViewById(R.id.email);
        phoneno=findViewById(R.id.empphone);
        Reasonofleave=findViewById(R.id.leavereason);
        descriptionbox=findViewById(R.id.description);

        sdate=findViewById(R.id.sd);
        edate=findViewById(R.id.ed);


        startdate=findViewById(R.id.startdate);
        enddate=findViewById(R.id.enddate);
        save=findViewById(R.id.btnSave);
        btnview=findViewById(R.id.btnview);

        requestQueue=Volley.newRequestQueue(getApplicationContext());

        startdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c= Calendar.getInstance();
                int  day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);

                dpd = new DatePickerDialog( MainActivity.this, new DatePickerDialog.OnDateSetListener(){
                    @Override
                    public void onDateSet(DatePicker datePicker, int mYear,int mMonth, int mDay){
                        sdate.setText(mDay + "/" +(mMonth+1) + "/" +mYear );
                    }
                }, day, month,year);
                dpd.show();
            }
        });
        enddate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                c= Calendar.getInstance();
                int  day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);

                dpd = new DatePickerDialog( MainActivity.this, new DatePickerDialog.OnDateSetListener(){
                    @Override
                    public void onDateSet(DatePicker datePicker, int mYear,int mMonth, int mDay){
                        edate.setText(mDay + "/" +(mMonth+1) + "/" +mYear );
                    }
                }, day, month,year);
                dpd.show();
            }
        });




        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendData(empid.getText().toString(),username.getText().toString(),empdept.getText().toString(),email.getText().toString(),phoneno.getText().toString(),Reasonofleave.getText().toString(),sdate.getText().toString(),edate.getText().toString(),descriptionbox.getText().toString());
            }
        });

        btnview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, EmpView.class));
            }
        });



    }

    private  void sendData(final String empid,final String username,final String empdept,final String email,final String phoneno,final String Reasonofleave,final String sdate,final String edate,final String descriptionbox){
        StringRequest request=new StringRequest(Request.Method.POST, sendUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                if (response.equals("You are registered successfully")){
                    Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.getMessage().toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            public Map<String,String> getParams(){
                Map<String, String> params=new HashMap<String, String>();
                params.put("empid",empid);
                params.put("username",username);
                params.put("empdept",empdept);
                params.put("email",email);
                params.put("phoneno",phoneno);
                params.put("Reasonofleave",Reasonofleave);
                params.put("sdate",sdate);
                params.put("edate",edate);
                params.put("descriptionbox",descriptionbox);


                Log.e("params",params.toString());
                return params;

            }
        };
        request.setRetryPolicy(new DefaultRetryPolicy(10000,1,1.0f));
        requestQueue.add(request);

    }

}