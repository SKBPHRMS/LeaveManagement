package com.myapp.hrmanagement;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class userview extends AppCompatActivity {
    ListView lv;

    String Sid;

    private static String emp_id[];
    private static String emp_name[];
    private static String department[];
    private static String sdate[];
    private static String reason[];
    private static String edate[];
    private static String des[];
    private static String sts[];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userview);
        Sid=getIntent().getStringExtra("ID");
        Toast.makeText(getApplicationContext(),Sid,Toast.LENGTH_LONG).show();
        lv = (ListView) findViewById(R.id.lv);
        Emp(Sid);
    }

    private void Emp(final String Semp_id){
        final ProgressDialog progressDialog = new ProgressDialog(userview.this);
        progressDialog.setTitle("Wait");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setIndeterminate(false);
        progressDialog.show();
        String uRl = "https://androidappforbisleri.000webhostapp.com/test/getUser.php";
        StringRequest request = new StringRequest(Request.Method.POST, uRl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray ja = new JSONArray(response);
                    JSONObject jo = null;

                    emp_id = new String[ja.length()];
                    emp_name = new String[ja.length()];
                    department = new String[ja.length()];
                    reason = new String[ja.length()];
                    sdate = new String[ja.length()];
                    edate = new String[ja.length()];
                    des = new String[ja.length()];
                    sts= new String[ja.length()];
                    for (int i = 0; i < ja.length(); i++) {
                        jo = ja.getJSONObject(i);
                        emp_id[i] = jo.getString("empid");
                        emp_name[i] = jo.getString("username");
                        department[i] = jo.getString("empdept");
                        reason[i] = jo.getString("Reasonofleave");
                        sdate[i] = jo.getString("sdate");
                        edate[i] = jo.getString("edate");
                        des[i] = jo.getString("descriptionbox");
                        sts[i] = jo.getString("status");
                    }
                    myadapter adptr = new myadapter(getApplicationContext(), emp_id, emp_name,department,reason,sdate,edate,des,sts);
                    lv.setAdapter(adptr);

                } catch (Exception ex) {

                    Toast.makeText(getApplicationContext(), ex.getMessage(), Toast.LENGTH_LONG).show();
                }
                progressDialog.dismiss();
            }

        },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(userview.this, error.toString(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> param = new HashMap<>();
                param.put("empid",Semp_id);
                return param;

            }
        };


        request.setRetryPolicy(new DefaultRetryPolicy(30000,DefaultRetryPolicy.DEFAULT_MAX_RETRIES,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getmInstance(userview.this).addToRequestQueue(request);

    }




    class myadapter extends ArrayAdapter<String> {
        Context context;
        String id[];
        String name[];
        String department[];
        String reason[];
        String sdate[];
        String edate[];
        String des[];
        String sts[];



        myadapter(Context c, String emp_id[], String emp_name[], String department[], String reason[], String sdate[], String edate[],String des[],String sts[]) {
            super(c, R.layout.emp_row, R.id.emp_id,emp_id);
            context = c;
            this.id = emp_id;
            this.name = emp_name;
            this.department = department;
            this.reason = reason;
            this.sdate = sdate;
           this.edate=edate;
            this.sts = sts;


        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = inflater.inflate(R.layout.emp_row, parent, false);
            TextView tv1 = row.findViewById(R.id.emp_id);
            TextView tv2 = row.findViewById(R.id.emp_name);
            TextView tv3 = row.findViewById(R.id.empdept);
            TextView tv4 = row.findViewById(R.id.reason);
            TextView tv5 = row.findViewById(R.id.sdate);
            TextView tv6 = row.findViewById(R.id.edate);
            TextView tv7 = row.findViewById(R.id.des);
            TextView tv8 = row.findViewById(R.id.status);


            tv1.setText("ID:"+id[position]);
            tv2.setText("Name:\n"+name[position]);
            tv3.setText("Department:\nRs."+department[position]);
            tv4.setText("Reason: \n"+reason[position]);
            tv5.setText("Start Date:"+sdate[position]);
            tv6.setText("End Date:\n"+edate[position]);
            tv7.setText("Description:"+des[position]);
            tv8.setText("Status: \n"+sts[position]);




            return row;
        }
    }
}